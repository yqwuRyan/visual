source (global)
source(ui)
source(server)
shinyApp(ui = ui, server = server)
